#!/bin/bash
echo "export IRVSPDATA="`pwd` >> ~/.bashrc
